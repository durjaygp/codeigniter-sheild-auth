<?php  $this->extend('master'); ?>
<?php $this->section('content'); ?>
<?php echo view('auth/login.php'); ?>
<?php $this->endSection(); ?>