<?php  $this->extend('master'); ?>

<?php $this->section('content'); ?>
<!--<button class="demo-button alertModalTrigger" data-type-alert-modal="modal-alert-warning" data-title-alert-modal="¡Advertencia!" data-icon-alert-modal="icon-emojiModal--warning" data-message-alert-modal="Este es un mensaje de advertencia.">Demo</button>-->

<!--<a href="#" class="alertModalTrigger" data-type-alert-modal="modal-alert-normal" data-title-alert-modal="Exito" data-icon-alert-modal="icon-emojiModal--fire" data-message-alert-modal="Estas on fire">Modal 2</a>-->
<div class="header-avatars">
    <div class="header-avatars__box">
        <div class="header-avatars__circle-avatar">
            <img src="/assets/img/avatars/diana1.webp" alt="avatar diana">
        </div>
        <div class="header-avatars__circle-avatar">
            <img src="/assets/img/avatars/ingrid1.webp" alt="avatar ingrid">
        </div>
        <div class="header-avatars__circle-avatar">
            <img src="/assets/img/avatars/jorge1.webp" alt="avatar jorge">
        </div>
    </div>
</div>
<section class="servicios-destacados">
    <h1>Soluciones Integrales en Automatización de Datos</h1>
    <p>Transformamos tus hojas de Excel en informes dinámicos y personalizados, optimizando la interpretación de tus datos. <strong>Informes a medida, adaptados a tus necesidades ✓</strong></p>
</section>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php $this->endSection(); ?>




