<!--Ventanas modales de alerta para activar con javascript-->


<div class="footer-content__container">
    <p>
        <i class="icon-copyright"></i>COPYRIGHT <?php echo date("Y"); ?>, Jorge Toledo
    </p>
    <p>
        &nbsp;<i class="icon-mail"></i> ifjtoledo@gmail.com, Dosquebradas-Colombia.
    </p>
    <p>
         &nbsp;Todos los derechos reservados.
    </p>
</div>
<script src="<?php echo base_url('assets/js/app.js'); ?>?v=<?php echo uniqid(); ?>"></script>

<!--<script src="<?php /*echo base_url('assets/js/app.js'); */?>"></script>-->